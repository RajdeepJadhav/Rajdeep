package com.Ait;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManyToOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
