package com.Ait.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Student {
	
	
	@Id
	private long sid;
	private String name;
	
	@ManyToOne
	@JoinColumn(name = "bid")
	private Book book;

}
