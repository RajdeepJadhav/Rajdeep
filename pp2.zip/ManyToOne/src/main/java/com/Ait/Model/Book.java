package com.Ait.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book {
		
	@Id
	private long bid;
	private String name;
}
