package com.Ait.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Area {
	
	@Id
	@GeneratedValue(strategy  = GenerationType.AUTO)
	private long area_id;
	private long area_code;
	private String area_name;
}
