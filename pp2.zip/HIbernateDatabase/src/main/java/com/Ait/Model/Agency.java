package com.Ait.Model;

import javax.persistence.Entity;


public class Agency {
	
	private long agency_id;
	private String agency_name;

}
