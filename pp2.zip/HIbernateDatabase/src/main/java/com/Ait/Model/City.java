package com.Ait.Model;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class City {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long city_id;
	private long city_code;
	private String city_name;
	@OneToMany(targetEntity =Area.class)
	@JoinColumn(name="city_id")
	private List<Area>area;
	@OneToOne
	private State state;
	
	
	
	
	

}
