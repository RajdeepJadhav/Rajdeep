

interface Food{
	
	public void display();
	
}

class Italian implements Food{
	
	public void display() 
	{
		System.out.println("in italian");
		
	}
}

public class Hello implements Food {


	public void display()
	{
		System.out.println("in hello");
		
	}
	
	public static void main(String[] args) {
		Food f=new Italian();
		Food f1=new Hello();
		f.display();
		f1.display();
		String a1="abc";
		a1.compareToIgnoreCase(a1);
		
	}

}
