package com.Ait;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Ait.Model.*;

@Controller
public class HomeController {
			
	
			@PostMapping("/home")
			public ModelAndView m1(@RequestParam("name") String n,@RequestParam("percent") int p,@RequestParam("city") String c)
			{
				ModelAndView mv=new ModelAndView("two");
				mv.addObject("username", n);
				return mv;
			}
			
			@PostMapping("/list")
			public ModelAndView m2(@RequestParam("name") String n,@RequestParam("percentage") int p,@RequestParam("city") String c)
			{	
				ArrayList<Student>arr=new ArrayList<>();
				ModelAndView mv=new ModelAndView("two");
				Student s1=new Student(1,n,p,c);
				arr.add(s1);
				arr.add(new Student(2,"omkar",78,"pune"));
				mv.addObject("studlist", arr);
				return mv;
			}

}
