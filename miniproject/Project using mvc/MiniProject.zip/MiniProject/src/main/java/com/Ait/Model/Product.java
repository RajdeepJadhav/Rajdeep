package com.Ait.Model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_product")
public class Product {
			
	@Id
	private int product_id;
	private String product_name;
	private int product_price;
	private String product_status;
	private int product_quantity;
	private String description;
	
	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	
	
	public Product() {}


	public Product(int product_id, String product_name, int product_price, String product_status,int qu,String d) {
		this.product_id = product_id;
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_status = product_status;
		this.product_quantity=qu;
		this.description=d;
	}
	
	public Product(String product_name, int product_price, String product_status,int qu) {
		this.product_name = product_name;
		this.product_price = product_price;
		this.product_status = product_status;
		this.product_quantity=qu;
	}
	

	public int getProduct_quantity() {
		return product_quantity;
	}


	public void setProduct_quantity(int product_quantity) {
		this.product_quantity = product_quantity;
	}


	public int getProduct_id() {
		return product_id;
	}


	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}


	public String getProduct_name() {
		return product_name;
	}


	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}


	public int getProduct_price() {
		return product_price;
	}


	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}


	public String getProduct_status() {
		return product_status;
	}


	public void setProduct_status(String product_status) {
		this.product_status = product_status;
	}
	
	
	
}
