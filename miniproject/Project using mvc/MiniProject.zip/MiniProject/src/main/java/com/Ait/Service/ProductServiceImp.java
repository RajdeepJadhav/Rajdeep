package com.Ait.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ait.Dao.ProductDao;
import com.Ait.Model.Product;

@Service
public class ProductServiceImp implements ProductService{

	@Autowired
	private ProductDao pdao;
	
	public boolean insertProduct(Product p) {
		pdao.insertProduct(p);
		return true;
	}

	public boolean updateProduct(Product p) {
		pdao.updateProduct(p);
		return true;
	}

	
	public boolean deleteProduct(Product p) {
		pdao.deleteProduct(p);
		return true;
	}

	public List<Product> getAllProductDetails() {
		
		return pdao.getAllProductDetails();
	}

	
	public Product getProductById(int pid) {
		
		return pdao.getProductById(pid);
	}

}
