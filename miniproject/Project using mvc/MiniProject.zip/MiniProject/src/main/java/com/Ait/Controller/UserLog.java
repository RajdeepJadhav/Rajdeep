package com.Ait.Controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Ait.Model.Item;
import com.Ait.Model.User;
import com.Ait.Service.UserService;

@Controller
public class UserLog {

	@Autowired
	private UserService userv;
	
	@GetMapping("/login")
	public String redirectToo() {
		return "login";
	}
	
	
	@GetMapping("/signup")
	public String redirectTo() {
		return "SignUpUser";
	}

	@GetMapping("/saveuser")
	public String insertUser(@RequestParam("name") String n, @RequestParam("password") String p,
			@RequestParam("gender") String g, @RequestParam("age") int a, @RequestParam("mobile") long m,@RequestParam("email") String e) {
		String rr="User";
		User aa = new User(n, p, g, a, m, e,rr);
		userv.insertIntoUser(aa);
		return "redirect:/login";
	}

	@GetMapping("/check")
	public String checkUser(@RequestParam("user_name") String n, @RequestParam("user_pass") String p,HttpServletRequest req) 
	{	
		HttpSession session=req.getSession();
		String mm="Admin";
		String m1="User";
		List<User> li = userv.getAllUsers();
		for (User u : li) {
			if (u.getUsername().equalsIgnoreCase(n) && u.getPassword().equalsIgnoreCase(p)
					&& u.getRole().equalsIgnoreCase(mm))
			{	
				session.setAttribute("username",u.getUsername());
				return "redirect:/productadmin";
			} 
			if (u.getUsername().equalsIgnoreCase(n) && u.getPassword().equalsIgnoreCase(p)
					&& u.getRole().equalsIgnoreCase(m1)) {
				ArrayList<Item>arr=new ArrayList<>();
				session.setAttribute("username",u.getUsername());
				session.setAttribute("itemlist",arr);
				return "forward:/Userdisplay";
			}
		}
		return "SignUpUser";

	}
	
	@GetMapping("/Users")
	public ModelAndView userInfo() 
	{	
		ModelAndView mv=new ModelAndView("user");
		List<User>list=userv.getAllUsers();
		mv.addObject("user", list);
		return mv;
	}
	
	@GetMapping("/Action")
	public ModelAndView userAction(@RequestParam("id") int id) 
	{	
		ModelAndView mv=new ModelAndView("edituser");
		User u=userv.getUserById(id);
		mv.addObject("use", u);
		return mv;
	}
	
	@GetMapping("/updateuser")
	public String userAction(@ModelAttribute("user") User u) 
	{	
		userv.updateUser(u);
		return "redirect:/Users";
	}
	
	

}
