package com.Ait.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.Ait.Model.Product;
import com.Ait.Service.ProductService;


@Controller
public class ProductAdminController {
	
	@Autowired
	private ProductService pserv;
	
	@GetMapping("/")
	public String homePage() 
	{
		return "HomePage"; 
	}
	
	@GetMapping("/productadmin")
	public ModelAndView getAllProducts() 
	{
		ModelAndView mv=new ModelAndView("ProductAdmin");
		List<Product>plist= pserv.getAllProductDetails();
		mv.addObject("productlist", plist);
		return mv;
	}
	
	@GetMapping("/Delete")
	public String deleteProduct(@RequestParam("id") int id) 
	{
		Product p=pserv.getProductById(id);
		if(p!=null) 
			pserv.deleteProduct(p);
		return "redirect:/productadmin";
	}
	
	@GetMapping("/Add")
	public String addProduct() 
	{
		return "AddProductAdmin";
	}
	
	@GetMapping("/save")
	public String saveProduct(@ModelAttribute("prodd") Product p) 
	{	
		pserv.insertProduct(p);
		return "redirect:/productadmin";
	}
	
	@GetMapping("/Edit")
	public ModelAndView editProduct(@RequestParam("id")int id) 
	{	
		ModelAndView mv=new ModelAndView("EditAdmin");
		Product p=pserv.getProductById(id);
		mv.addObject("pro", p);
		return mv;
	}
	
	@GetMapping("/Update")
	public String updateProduct(@RequestParam("id") int id,@RequestParam("product_name") String pname,@RequestParam("price") int p,@RequestParam("product_status") String status,@RequestParam("quantity")int quantity,@RequestParam("description")String d) 
	{
		Product p1=new Product(id,pname,p,status,quantity,d);
		pserv.updateProduct(p1);
		return "redirect:/productadmin";
	}
	
	@GetMapping("/Back")
	public String homeIt() 
	{
		return"redirect:/productadmin";
	}
	
	
	

}

	