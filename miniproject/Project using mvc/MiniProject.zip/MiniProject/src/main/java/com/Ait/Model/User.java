package com.Ait.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_user")
public class User {

	@Id
	private int user_id;
	private String username;
	private String password;
	private String gender;
	private int age;
	private long mobile;
	private String email;
	private String role;

	public User() {
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public User(int user_id, String username, String password, String gender, int age, long mobile, String email,String role) {
		this.user_id = user_id;
		this.username = username;
		this.password = password;
		this.gender = gender;
		this.age = age;
		this.mobile = mobile;
		this.email = email;
		this.role=role;
	}

	public User(String name, String pass, String gender2, int age2, long mobile2, String email2) {
		this.username = name;
		this.password = pass;
		this.gender = gender2;
		this.age = age2;
		this.mobile = mobile2;
		this.email = email2;
	}

	public User(String n, String p, String g, int a, long m, String e, String rr) {
		this.username=n;
		this.password=p;
		this.age=a;
		this.mobile=m;
		this.gender=g;
		this.email=e;
		this.role=rr;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
