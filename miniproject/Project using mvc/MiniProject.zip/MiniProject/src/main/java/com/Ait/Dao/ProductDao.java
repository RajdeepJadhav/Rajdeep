package com.Ait.Dao;

import java.util.List;

import com.Ait.Model.Product;

public interface ProductDao {
	
		
		boolean insertProduct(Product p);
		boolean updateProduct(Product p);
		boolean deleteProduct(Product p);
		List<Product> getAllProductDetails();
		Product getProductById(int pid);
		
		

}
