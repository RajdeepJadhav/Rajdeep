package com.Ait.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Ait.Model.Item;
import com.Ait.Model.Product;
import com.Ait.Model.User;
import com.Ait.Service.OrderService;
import com.Ait.Service.ProductService;;

@Controller
public class ProductUserController {
	
	@Autowired
	private ProductService pserv; 	

	@GetMapping("/Userdisplay")
	public ModelAndView displayProductsToUser() {
		
		ModelAndView mv = new ModelAndView("ProductUser");
		List<Product> li = pserv.getAllProductDetails();
		mv.addObject("prod", li);
		return mv;
	}

	@GetMapping("/productuser")
	public String loginPage() {
		return "Login";
	}

	@GetMapping("/Addtocart")
	public String addToCart(HttpServletRequest req) {
		HttpSession session = req.getSession(false);
			ArrayList<Item>al=(ArrayList<Item>)session.getAttribute("itemlist");
			int pid = Integer.parseInt(req.getParameter("id"));
			Product p1 = pserv.getProductById(pid);
			al.add(new Item(p1.getProduct_id(), p1.getProduct_name(), p1.getProduct_price(),1));
			System.out.println("***************"+al);
			session.setAttribute("cartlist", al);
			return "forward:/Userdisplay";
		
	}

	@GetMapping("/viewcart")
	public String viewCart(HttpServletRequest req, Model m) {
		HttpSession session = req.getSession(false);
		if (session != null) 
		{	
			ArrayList<Item> arr = (ArrayList<Item>) session.getAttribute("cartlist");
			m.addAttribute("cartlist", arr);
			System.out.println("***************"+arr);
		}
		return "viewcart";
	}

}
