package com.Ait.Service;

import java.util.List;

import com.Ait.Model.Order;

public interface OrderService {

	
	
		List<Order>getOrder();
}
