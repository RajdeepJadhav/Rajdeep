package com.Ait.Service;

import java.util.List;

import com.Ait.Model.User;

public interface UserService {
	
	
	boolean insertIntoUser(User u);
	List<User> getAllUsers();
	User getUserById(int id);
	boolean updateUser(User u);

}
