package com.Ait.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.Ait.Model.Cart;
import com.Ait.Model.Product;
import com.Ait.Service.CartService;

@Controller
public class CartController {
		
	@Autowired
	private CartService cserv;
	
	@GetMapping("/insertintocart")
	public ModelAndView addToCart(@ModelAttribute("prod") Product p) 
	{	
		List<Product>li=new ArrayList<>();
		li.add(p);
		System.out.println(li);
		Cart c=new Cart(li);
		cserv.insertIntoCart(c);
		return null;
	}
	
}
