package com.Ait.Dao;

import java.util.List;

import com.Ait.Model.User;

public interface UserDao {
			
	
			boolean insertIntoUser(User u);
			List<User> getAllUsers();
			User getUserById(int id);
			boolean updateUser(User u);
			
}
