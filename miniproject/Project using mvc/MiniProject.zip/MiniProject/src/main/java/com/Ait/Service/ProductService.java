package com.Ait.Service;

import java.util.List;

import com.Ait.Model.Product;

public interface ProductService {

	
	
	boolean insertProduct(Product p);
	boolean updateProduct(Product p);
	boolean deleteProduct(Product p);
	List<Product> getAllProductDetails();
	Product getProductById(int pid);
}
