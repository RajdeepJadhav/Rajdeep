package com.Ait.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ait.Dao.UserDao;
import com.Ait.Model.User;

@Service
public class UserServiceImp implements UserService{

	@Autowired
	private UserDao udao;
	
	
	public boolean insertIntoUser(User u) {
		return udao.insertIntoUser(u);
	}

	public List<User> getAllUsers() {
		
		return udao.getAllUsers();
	}

	public User getUserById(int id) {
		// TODO Auto-generated method stub
		return udao.getUserById(id);
	}

	@Override
	public boolean updateUser(User u) {
		return udao.updateUser(u);
	}




}
