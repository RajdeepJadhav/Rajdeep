package com.Ait.Service;

import com.Ait.Model.Cart;

public interface CartService{
		
	boolean insertIntoCart(Cart c);
}
