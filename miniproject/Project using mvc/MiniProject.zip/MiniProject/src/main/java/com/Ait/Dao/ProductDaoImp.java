package com.Ait.Dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Ait.Model.Product;

@Repository
@Transactional
public class ProductDaoImp implements ProductDao{
	
	@Autowired
	private SessionFactory ss;
	
	public boolean insertProduct(Product p) {
		 ss.getCurrentSession().save(p);
		 return true;
	}

	public boolean updateProduct(Product p) {
		
		ss.getCurrentSession().saveOrUpdate(p);
		return true;
	}

	
	public boolean deleteProduct(Product p) {
		
		ss.getCurrentSession().delete(p);;
		return true;
	}


	@Override
	public List<Product> getAllProductDetails() {
		Query<Product>q=ss.getCurrentSession().createQuery("from Product");
		List<Product>li=q.list();	
		return li;
	}

	@Override
	public Product getProductById(int pid) {	
	
		return ss.getCurrentSession().get(Product.class,pid);
	}
	
	
	
}


