package com.Ait.Dao;

import com.Ait.Model.Cart;

public interface CartDao {
	
	
	boolean insertIntoCart(Cart c);

}
