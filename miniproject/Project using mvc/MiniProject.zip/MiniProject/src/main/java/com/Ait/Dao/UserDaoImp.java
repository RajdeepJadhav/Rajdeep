package com.Ait.Dao;

import java.util.List;

import javax.persistence.NamedNativeQuery;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.Ait.Model.User;

@Repository
@Transactional
public class UserDaoImp implements UserDao{
	
	@Autowired
	private SessionFactory ss;
	
	
	public boolean insertIntoUser(User u) {
		 ss.getCurrentSession().save(u);
		 return true;
	}


	@Override
	public List<User> getAllUsers() {
		Query<User> q=ss.getCurrentSession().createQuery("from User");
		List<User>li=q.list();
		return li;
	}



	public User getUserById(int id) {
		
		return ss.getCurrentSession().get(User.class,id);
	}


	@Override
	public boolean updateUser(User u) {
			ss.getCurrentSession().update(u);
		return true;
	}

	

}
