package com.Ait;

import org.springframework.stereotype.Component;

@Component
public class Course {
		private String cname;
		private int fees;
		@Override
		public String toString() {
			return "cname=" + cname + ", fees=" + fees + "]";
		}
		public String getCname() {
			return cname;
		}
		public void setCname(String cname) {
			this.cname = cname;
		}
		public int getFees() {
			return fees;
		}
		public void setFees(int fees) {
			this.fees = fees;
		}
		public Course(String cname, int fees) {
			super();
			this.cname = cname;
			this.fees = fees;
		}
		
		public Course() {System.out.println("in course def");}
}
