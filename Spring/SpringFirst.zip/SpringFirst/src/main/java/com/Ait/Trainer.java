package com.Ait;

import org.springframework.stereotype.Component;

@Component
public class Trainer {
	
	private String tname;
	
	public Trainer() {System.out.println("in trainer def");}

	public Trainer(String tname) {
		super();
		this.tname = tname;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	@Override
	public String toString() {
		return "Trainer [tname=" + tname + "]";
	}
	
	

}
