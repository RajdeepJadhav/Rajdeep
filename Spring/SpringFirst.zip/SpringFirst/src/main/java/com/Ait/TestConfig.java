package com.Ait;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class TestConfig {

	public static void main(String[] args) {
			AbstractApplicationContext ctx=new AnnotationConfigApplicationContext(SpringConfig.class);
			Student s1=(Student)ctx.getBean("s1");
			System.out.println(s1);
	}

}
