package com.Ait;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestMain {

	public static void main(String[] args) {
			ApplicationContext a=new ClassPathXmlApplicationContext("Spring.xml");
			//Student s1=a.getBean(Student.class,"student");
			Student s1=(Student)a.getBean("s1");
			System.out.println(s1);
	
	}

}
