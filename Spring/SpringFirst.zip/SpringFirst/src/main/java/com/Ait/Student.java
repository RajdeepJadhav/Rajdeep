package com.Ait;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("s1")
public class Student implements InitializingBean,DisposableBean {
		private int sid;
		private String sname;
		private int rollno;
		private int percent;
		@Autowired
		private Course course;
		@Autowired
		private Trainer trainer;
		
		public Student() {System.out.println("in default student");}
		
		public Student(int sid, String sname, int rollno, int percent,Course course) {
			this.sid = sid;
			this.sname = sname;
			this.rollno = rollno;
			this.percent = percent;
			this.course=course;
		}
		public Student(Trainer trainer) {
			super();
			this.trainer = trainer;
		}
		public int getSid() {
			return sid;
		}
		public void setSid(int sid) {
			this.sid = sid;
		}
		public String getSname() {
			return sname;
		}
		public void setSname(String sname) {
			this.sname = sname;
		}
		public int getRollno() {
			return rollno;
		}
		public void setRollno(int rollno) {
			this.rollno = rollno;
		}
		public int getPercent() {
			return percent;
		}
		public void setPercent(int percent) {
			this.percent = percent;
		}
		public String toString() {
			return "Student [sid=" + sid + ", sname=" + sname + ", rollno=" + rollno + ", percent=" + percent +" course="+course+" trainer="+trainer;
		}
		public void setCourse(Course course) 
		{
			this.course=course;
		}
		
		public Course getCourse() 
		{
			return course;
		}
		
		public void setTrainer(Trainer t) 
		{
			this.trainer=t;
		}
		
		public Trainer getTrainer() 
		{
			return trainer;
		}

		public void destroy() throws Exception {
			// TODO Auto-generated method stub
			
		}

		public void afterPropertiesSet() throws Exception {
			// TODO Auto-generated method stub
			
		}
		
		
}
