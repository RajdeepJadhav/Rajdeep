package com.Ait.Dao;

import java.util.List;

import com.Ait.Model.Student;

interface StudentDao {
	boolean addStudent(Student s);
	boolean deleteStudent(int id);
	boolean updateStudent(Student s);
	List<Student>getAllStudent();
	Student getStudentById(int id);
}
