package com.Ait.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class StudentController {
	
	
	public String b1() 
	{
		return "two";
	}

}
