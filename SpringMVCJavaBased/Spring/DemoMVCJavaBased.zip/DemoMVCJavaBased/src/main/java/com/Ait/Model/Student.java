package com.Ait.Model;

public class Student {

}
