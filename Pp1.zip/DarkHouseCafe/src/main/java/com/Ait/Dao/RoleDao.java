package com.Ait.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Ait.Model.Role;

public interface RoleDao extends JpaRepository<Role, Integer>{
	
	
	
}
