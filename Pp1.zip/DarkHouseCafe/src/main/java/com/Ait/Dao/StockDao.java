package com.Ait.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Ait.Model.Stock;

public interface StockDao extends JpaRepository<Stock,Integer> {

}
