package com.Ait.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Ait.Model.Cart;

public interface CartDao extends JpaRepository<Cart,Integer>{



}
