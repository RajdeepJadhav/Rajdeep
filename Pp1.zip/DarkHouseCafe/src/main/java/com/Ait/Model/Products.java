package com.Ait.Model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class Products {
	
	@Id
	@GeneratedValue
	private int productid;
	private String productname;
	private double price;
	private String description;	
	boolean availablestatus;
	
	
	
	public Products(int productid, String productname, double price, String description) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.price = price;
		this.description = description;
	}
	public Products() {
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public boolean isAvailablestatus() {
		return availablestatus;
	}
	public void setAvailablestatus(boolean availablestatus) {
		this.availablestatus = availablestatus;
	}
	public Products(int productid, String productname, double price, String description, boolean availablestatus) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.price = price;
		this.description = description;
		this.availablestatus = availablestatus;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String toString() {
		return "Products [productid=" + productid + ", productname=" + productname + ", price=" + price
				+ ", description=" + description + "]";
	}
	
	

}
