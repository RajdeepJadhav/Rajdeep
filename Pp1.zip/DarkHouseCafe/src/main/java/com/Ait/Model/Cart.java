package com.Ait.Model;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Cart {

	@Id
	@GeneratedValue
	private int cartid;
	@OneToMany
	@Column(name = "listofproducts" ,unique = false)
	private List<Products> list;

	public Cart(int cartid, List<Products> list) {
		super();
		this.cartid = cartid;
	
		this.list = list;
	}

	public Cart(List<Products> list) {
		this.list = list;
	}

	public Cart() {

	}

	public long getCartid() {
		return cartid;
	}

	public void setCartid(int cartid) {
		this.cartid = cartid;
	}

	public List<Products> getList() {
		return list;
	}

	public void setList(List<Products> list) {
		this.list = list;
	}

}
