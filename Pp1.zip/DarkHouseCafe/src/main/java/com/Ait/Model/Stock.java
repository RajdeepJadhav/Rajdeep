package com.Ait.Model;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class Stock {
	
	@Id
	@GeneratedValue
	private int stockid;
	@OneToOne(cascade = CascadeType.ALL)
	private Products products;
	private int quantity;
	public int getStockid() {
		return stockid;
	}
	public void setStockid(int stockid) {
		this.stockid = stockid;
	}
	public Products getProducts() {
		return products;
	}
	public void setProducts(Products products) {
		this.products = products;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Stock(int stockid, Products products, int quantity) {
		super();
		this.stockid = stockid;
		this.products = products;
		this.quantity = quantity;
	}
	public Stock() {
		
	}
	public Stock(Products products, int quantity) {
		super();
		this.products = products;
		this.quantity = quantity;
	}
	
	public String toString() {
		return "Stock [stockid=" + stockid + ", products=" + products + ", quantity=" + quantity + "]";
	}
	
	
	
	

}
