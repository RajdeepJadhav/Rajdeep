package com.Ait.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Role {
	
	@Id
	@GeneratedValue
	private long roleid;
	private String role;
	public Role(long roleid, String role) {
		super();
		this.roleid = roleid;
		this.role = role;
	}
	public Role() {
		super();
	}
	public long getRoleid() {
		return roleid;
	}
	public void setRoleid(int roleid) {
		this.roleid = roleid;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Role [roleid=" + roleid + ", role=" + role + "]";
	}
	
	
	

}
