package com.Ait.Service;

import java.util.List;
import java.util.Optional;

import com.Ait.Model.Products;
import com.Ait.Model.Stock;

public interface StockService {

	
	List<Stock> getStockInfo();
	void addStock(Stock stock);
	
}
