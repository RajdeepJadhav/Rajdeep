package com.Ait.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ait.Dao.ProductDao;
import com.Ait.Model.Products;

@Service
public class ProductServiceImp implements ProductService{
	
	@Autowired
	private ProductDao pdao;

	public List<Products> getAllProducts() {
		List<Products>list=pdao.findAll();return list;
	}

	public Products findProductById(int id) {
		Products p=pdao.findById(id);
		return p;
	}
	public void updateProduct(Products p) {
			pdao.save(p);	
	}

	public void deleteProduct(int id) {
			pdao.deleteById(id);
	}

	@Override
	public void saveProduct(Products p) {
			pdao.save(p);
		
	}



	
	
	

	
	
}
