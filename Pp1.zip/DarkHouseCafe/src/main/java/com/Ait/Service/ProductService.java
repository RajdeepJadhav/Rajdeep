package com.Ait.Service;

import java.util.List;
import com.Ait.Model.Products;

public interface ProductService {

	
	List<Products> getAllProducts();
	Products findProductById(int id);
	void updateProduct(Products p);
	void deleteProduct(int id);
	void saveProduct(Products p);


}
