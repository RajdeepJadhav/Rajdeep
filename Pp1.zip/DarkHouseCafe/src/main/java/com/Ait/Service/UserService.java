package com.Ait.Service;

import java.util.List;

import com.Ait.Model.Users;

public interface UserService {

	
	List<Users> getAllUser();
	void saveUser(Users u);
}
