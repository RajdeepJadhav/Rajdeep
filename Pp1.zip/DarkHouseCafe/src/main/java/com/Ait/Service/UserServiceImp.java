package com.Ait.Service;

import java.util.List;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ait.Dao.UserDao;
import com.Ait.Model.Users;

@Service
public class UserServiceImp implements UserService{

	@Autowired
	private UserDao udao;

	
	
	public List<Users> getAllUser() {
		
		return udao.findAll();
	}

	public void saveUser(Users u) {
		udao.save(u);
		
	}

	
	

}
