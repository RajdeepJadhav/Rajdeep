package com.Ait.Service;
import com.Ait.Model.Cart;
public interface CartService {

	 void saveProductIntoCart(Cart c);
	
}
