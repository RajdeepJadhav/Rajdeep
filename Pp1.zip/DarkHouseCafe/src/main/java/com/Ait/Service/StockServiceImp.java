package com.Ait.Service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import com.Ait.Dao.StockDao;
import com.Ait.Model.Products;
import com.Ait.Model.Stock;

@Service
public class StockServiceImp implements StockService{

	@Autowired
	private StockDao sdao;

	
	public List<Stock> getStockInfo() {
		
		return sdao.findAll();
	}



	public void addStock(Stock stock) {
		sdao.save(stock);
		
	}






	
	



	

	
	
	
	

	
	
	
}
