package com.Ait.Controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class LoginController {
	
	
	
	@RequestMapping("/")
	public String homePage() 
	{
		return "HomePage";
	}
	
	@RequestMapping("/SignUp")
	public String signUpUser() 
	{
		return "signup";
	}
	
	@RequestMapping("/Login")
	public String login() 
	{
		return "Login";
	}
	
	@GetMapping("/addproduct")
	public String addProducts() 
	{
		return "addproduct";
	}
	
	@GetMapping("logout")
	public String logoutUser(HttpServletRequest request) {
		HttpSession session=request.getSession(false);
		session.invalidate();
		return "HomePage";
	}
	


	
}
