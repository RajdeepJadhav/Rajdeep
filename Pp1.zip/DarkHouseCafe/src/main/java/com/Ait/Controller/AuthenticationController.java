package com.Ait.Controller;



import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Ait.Model.Products;
import com.Ait.Model.Role;
import com.Ait.Model.Users;
import com.Ait.Service.UserService;


@Controller
public class AuthenticationController {
	
	@Autowired
	private UserService userv;
	
	@PostMapping("saveuser")
	public String saveUser(@RequestParam("firstname") String firstname,@RequestParam("lastname") String lastname,@RequestParam("username") String username
			,@RequestParam("email") String email,@RequestParam("password") String password,@RequestParam("gender") String gender ,@RequestParam("address")String address
			,@RequestParam("age") int age,@RequestParam("contact") long contact) 
	{	
		
		Role r=new Role();
		r.setRoleid(2);
		String pass=org.mindrot.jbcrypt.BCrypt.hashpw(password,org.mindrot.jbcrypt.BCrypt.gensalt());
		//String pass=encryptPassword(password);
		Users u=new Users(firstname,lastname,username,pass,email,gender,r,age,contact,address);
		userv.saveUser(u);
		return "Login";
	}
	

	@GetMapping("check")
	public String checkUser(@RequestParam("username") String username,@RequestParam("password") String password ,HttpServletRequest req) 
	{	
			
		HttpSession session=req.getSession();
		List<Products>li=new ArrayList<>();
		session.setAttribute("list",li);
		session.setAttribute("username",username);		
		List<Users>list=userv.getAllUser();
		for(Users u:list) {
			if(BCrypt.checkpw(password, u.getPassword())==false &&u.getUsername().equalsIgnoreCase(username)) {
				req.setAttribute("status","Invalid Password");
				return "Login";	
			}
			if(u.getUsername().equalsIgnoreCase(username)&&u.getRole().getRoleid()==1&&BCrypt.checkpw(password,u.getPassword())) 
			{
				session.setAttribute("list",li);
				return "redirect:/allproducts";
			}
			/*
			 * if(BCrypt.checkpw(password, u.getPassword())==true
			 * &&u.getUsername()!=username) {
			 * req.setAttribute("status1","Invalid Username"); return "Login"; }
			 */
			if(u.getUsername().equalsIgnoreCase(username)&&BCrypt.checkpw(password,u.getPassword())&&u.getRole().getRoleid()==2) 
			{
				return "redirect:/getproductsforuser";
			}
		}
		return "signup";
	}
	
	
	

}
