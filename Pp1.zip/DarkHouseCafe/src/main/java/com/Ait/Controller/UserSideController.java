package com.Ait.Controller;


import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.Ait.Model.Products;
import com.Ait.Model.Users;
import com.Ait.Service.ProductService;
import com.Ait.Service.UserService;
@Controller
public class UserSideController {
	
	List<Products>list;
	
	@Autowired
	private ProductService pserv;
	
	@Autowired
	private UserService userv;
	
	@GetMapping("getproductsforuser")
	public ModelAndView getAllProducts(HttpServletRequest req) 
	{
		HttpSession session=req.getSession(false);
		session.getAttribute("list");
		list=pserv.getAllProducts();
		ModelAndView mv=new ModelAndView("productuser");
		mv.addObject("list",list);
		return mv;
	
	}
	
	@GetMapping("profile")
	public String userInformation(HttpServletRequest req) {
		HttpSession session=req.getSession(false);
		
		Object obj=session.getAttribute("username");
		return "redirect:/getuserinfo";
	}
	
	@RequestMapping("getuserinfo")
	public ModelAndView getUserInfo(HttpServletRequest req) {
		HttpSession session=req.getSession(false);
		ModelAndView mv=new ModelAndView("UserProfile");
		Users u1=new Users();
		String obj=(String) session.getAttribute("username");
		List<Users>li=userv.getAllUser();
		for(Users u:li) {
			if(u.getUsername().equalsIgnoreCase(obj)) {
				 u1=u;
			}
		}
		mv.addObject("user",u1);
		session.setAttribute("firstname",u1.getFirstname());
		session.setAttribute("lastname",u1.getLastname());
		session.setAttribute("email",u1.getEmail());
		session.setAttribute("age",u1.getAge());
		session.setAttribute("username",u1.getUsername());
		return mv;
	}
	

	
	
}
