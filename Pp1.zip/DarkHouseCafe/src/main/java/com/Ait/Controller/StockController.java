package com.Ait.Controller;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.Ait.Model.Products;
import com.Ait.Model.Stock;	
import com.Ait.Service.ProductService;
import com.Ait.Service.StockService;

@Controller
public class StockController {
	
	@Autowired
	private StockService stockServe;
	
	@Autowired
	private ProductService pserv;
	
	@GetMapping("stock")
	public ModelAndView getStockInfo() {
		ModelAndView mv=new ModelAndView("stockinfo");
		List<Stock>stocklist=stockServe.getStockInfo();
		mv.addObject("stocklist", stocklist);
		return mv;
	}
	
	@GetMapping("addstock")
	public ModelAndView addStock(@RequestParam("id") int id) {
		ModelAndView mv=new ModelAndView("addsinglestock");
		Products pr=pserv.findProductById(id);
		mv.addObject("pro", pr);
		return mv;
	}
	
	@RequestMapping("insertstock")
	public String insertStock(@ModelAttribute("product")Products p,@RequestParam("quantity") int quantity) {
		List<Stock>li=stockServe.getStockInfo();
		if(li==null) {
			Stock s1=new Stock(p,quantity);
			stockServe.addStock(s1);
		}
		Iterator<Stock>itr=li.iterator();
		while(itr.hasNext())
		{
			Stock stock=itr.next();
			System.out.println(stock);
			if(stock.getProducts().getProductid()==p.getProductid())
			{
				stock.setQuantity(quantity);	
				stockServe.addStock(stock);
				return "success";	
			}
			if(stock.getProducts().getProductid()!=p.getProductid()) 
			{
				Stock s1=new Stock(p,quantity);
				stockServe.addStock(s1);
				return "success";
			}
		}
			return "pp1";
	}
	
	
	

}
