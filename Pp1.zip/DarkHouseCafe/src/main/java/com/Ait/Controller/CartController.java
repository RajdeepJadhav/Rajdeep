package com.Ait.Controller;
import java.util.Iterator;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.Ait.Model.Products;
import com.Ait.Service.CartService;
import com.Ait.Service.ProductService;

@Controller
public class CartController {
	
	
	@Autowired()
	private ProductService pserv;
	
	@Autowired
	private CartService cserv;

	


	@GetMapping("Addtocart")
	public String addToCart(@RequestParam("id") int id ,HttpServletRequest req) 
	{	
		HttpSession session=req.getSession(false);
		List<Products>li=(List<Products>) session.getAttribute("list");
		Products p=pserv.findProductById(id);
		li.add(p);
		session.setAttribute("listofproducts",li);
		return "redirect:/getproductsforuser";
	}
	
	
	@GetMapping("viewcart")
	public ModelAndView saveIntoCart(HttpServletRequest req ,HttpStatus status) {
		HttpSession session=req.getSession(false);
		ModelAndView mv=new ModelAndView("viewcart");
		String emptyCart="Your cart is empty";
		List<Products>list=(List<Products>) session.getAttribute("listofproducts");
		if(list==null) {
				session.setAttribute("emptycart",emptyCart);

		}
		else
			mv.addObject("list",list);
			return mv;
		}
	
	@RequestMapping("remove")
	public ModelAndView removeItem(@RequestParam("id") int id ,HttpServletRequest req) {
			HttpSession session=req.getSession(false);
			ModelAndView mv=new ModelAndView("viewcart");
			List<Products>list=(List<Products>) session.getAttribute("list");
			Products p=pserv.findProductById(id);
			System.out.println(list);
			Iterator<Products>itr=list.iterator();
			while(itr.hasNext()) {
				Products p1=itr.next();
				if(p1.getProductid()==p.getProductid()&&p1.getProductname().equals(p.getProductname())) {
					itr.remove();
				}
			}
			System.out.println(list);
			mv.addObject("list",list);
			session.setAttribute("list",list);
			return mv;
	}
	
}
	

