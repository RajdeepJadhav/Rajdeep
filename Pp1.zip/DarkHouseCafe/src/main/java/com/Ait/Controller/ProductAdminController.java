package com.Ait.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.Ait.Model.Products;
import com.Ait.Model.Users;
import com.Ait.Service.ProductService;
import com.Ait.Service.StockService;
import com.Ait.Service.UserService;

@Controller
public class ProductAdminController {

	// automatic dependency injection
	@Autowired
	private ProductService pserv;

	@Autowired
	private UserService userv;
	
	@Autowired
	private StockService stockServe;

	// fetching all products
	@RequestMapping("allproducts")
	public ModelAndView getAllProducts(HttpServletRequest req) 
	{
		HttpSession hs = req.getSession(false);
		long creationtime = hs.getCreationTime();
		hs.setAttribute("rajdeep", creationtime);
		Object sessiontrack = hs.getAttribute("rajdeep");
		System.out.println(sessiontrack);
		ModelAndView mv = new ModelAndView("ProductAdmin");
		List<Products> list = pserv.getAllProducts();
		mv.addObject("products", list);
		return mv;
	}

	// editing current product by id
	@RequestMapping("Edit")
	public ModelAndView editProduct(@RequestParam("id") int id, HttpServletRequest req) 
	{
		HttpSession hs = req.getSession(false);
		long creationtime = hs.getCreationTime();
		hs.setAttribute("rajdeep", creationtime);
		Object sessiontrack = hs.getAttribute("rajdeep");
		System.out.println(sessiontrack);
		Products p = pserv.findProductById(id);
		ModelAndView mv = new ModelAndView("EditProduct");
		mv.addObject("pro", p);
		return mv;
	}

	// updating current product
	@RequestMapping("update")
	public String updateProduct(@ModelAttribute("product") Products p, @RequestParam("productid") int id,
			HttpServletRequest req) 
	{
		HttpSession hs = req.getSession(false);	
		pserv.saveProduct(p);
		return "redirect:/allproducts";
	}

	// deleting current product
	@RequestMapping("Delete")
	public String deleteProduct(@RequestParam("id") int id) 
	{
		
		pserv.deleteProduct(id);
		return "redirect:/allproducts";
	}

	// adding new product
	@RequestMapping("Add")
	public String addProducts() {
		return "addproduct";
	}

	@RequestMapping("save")
	public String saveProduct(@ModelAttribute("product") Products p) 
	{	
		
		pserv.saveProduct(p);
		return "redirect:/allproducts";
	}

	@GetMapping("Users")
	public ModelAndView allUserInfo(HttpServletRequest req) 
	{
		HttpSession hs = req.getSession(false);
		long creationtime = hs.getCreationTime();
		hs.setAttribute("rajdeep", creationtime);
		Object sessiontrack = hs.getAttribute("rajdeep");
		System.out.println(sessiontrack);
		ModelAndView mv = new ModelAndView("AllUsersAdmin");
		List<Users> list = userv.getAllUser();
		mv.addObject("users", list);
		return mv;
	}
	
	
	
}
