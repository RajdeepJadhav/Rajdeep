package com.Ait.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name="author")
public class Author {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long authorid;
	private String authorName;
	@ManyToOne(cascade = CascadeType.ALL ,fetch = FetchType.LAZY)
	@JoinColumn(name="zipid")
	private Zipcode zipcode;
	@ManyToMany(mappedBy = "category" ,fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	private List<Book>booklist=new ArrayList<>(); 	
	public Author() {

	}
	public Author( String authorName, Zipcode zipcode, List<Book> booklist) {
		this.authorName = authorName;
		this.zipcode = zipcode;
		this.booklist = booklist;
	}
	
	public void addBook(Book book) {
		booklist.add(book);
	}
	
	public void deleteBook(Book book) {
		booklist.remove(book);
	}

}
