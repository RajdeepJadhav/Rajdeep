package com.Ait.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@Data
@Table(name="book")
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long bookid;
	private String bookName;
	@ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinTable(name="book_author",
	joinColumns = @JoinColumn(name="book_id"),
	inverseJoinColumns = @JoinColumn(name="author_id")
			)
	private List<Author>authorList=new ArrayList<>();
	@ManyToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name="categoryid")
	private Category category;
	public Book() {
	
	}
	public Book( String bookName, List<Author> authorList, Category category) {
		this.bookName = bookName;
		this.authorList = authorList;
		this.category = category;
	}
	
	public void addAuthor(Author author) {
		authorList.add(author);
	}
	
	public void removeAuthor(Author author) {
		authorList.remove(author);
	}
}
