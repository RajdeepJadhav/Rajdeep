package com.Ait.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name="zipcode")
public class Zipcode {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long zipid;
	private String zipname;
	@OneToOne
	@JoinColumn(name="cityid")
	private City city;
	public Zipcode() {
	
	}
	public Zipcode( String name, City city) {
		
		this.zipname = name;
		this.city = city;
	}
	
	

}
