package com.Ait.Dto.RequestDto;

import lombok.Data;

@Data
public class AuthorDto {

	private String authorname;
	private long zipid;
	
	
}
