package com.Ait.Dto.RequestDto;

import lombok.Data;

@Data
public class CategoryDto {
	
	private String categoryname;
	

}
