package com.Ait.Dto.RequestDto;

import java.util.List;

import lombok.Data;

@Data
public class BookDto {
	
	private String bookname;
	private List<Long>authorid;
	private long categoryid;

}
