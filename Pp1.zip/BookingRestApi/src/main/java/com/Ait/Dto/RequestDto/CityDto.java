package com.Ait.Dto.RequestDto;

import lombok.Data;

@Data
public class CityDto {

	
	private String cityname;
}
