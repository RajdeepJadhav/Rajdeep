package com.Ait.Dto.RequestDto;

import lombok.Data;

@Data
public class ZipcodeDto {

	private String name;
	private long cityid;
}
