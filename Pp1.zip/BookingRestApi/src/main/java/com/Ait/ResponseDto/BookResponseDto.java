package com.Ait.ResponseDto;

import java.util.List;

import lombok.Data;

@Data
public class BookResponseDto {

	private long bookid;
	private String bookname;
	private List<String>authorNames;
	private String categoryname;
}
