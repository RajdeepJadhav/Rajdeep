package com.Ait.ResponseDto;

import java.util.List;

import lombok.Data;

@Data
public class CategoryResponseDto {
	
	private long categoryid;
	private String categoryname;
	private List<String>bookName;
	
	
}
