package com.Ait.ResponseDto;

import java.util.List;

import lombok.Data;

@Data
public class AuthorResponseDto {
	
	private long authorid;
	private String authorname;
	private List<String>booklist;
	private String zipname;

}
