package com.example.demo;

import javax.persistence.Id;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo21Application {
	

	public static void main(String[] args) {
		SpringApplication.run(Demo21Application.class, args);
	
	}
	
	
	
}
