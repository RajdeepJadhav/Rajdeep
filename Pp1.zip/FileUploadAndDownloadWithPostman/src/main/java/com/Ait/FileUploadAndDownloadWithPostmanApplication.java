package com.Ait;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadAndDownloadWithPostmanApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileUploadAndDownloadWithPostmanApplication.class, args);
	}

}
